<div class=" bg_212 shadow-lg">

        <nav class="container navbar navbar-expand-lg animated slideInDown navbar-light bg_212 pl-4 pr-4 pt-2 pb-2 ">
        <!-- <nav className="navbar navbar-expand-lg fixed-top animated slideInDown navbar-light bg-dark pl-4 pr-4 pt-2 pb-2"> sticky header -->
        
            <a class="navbar-brand" href="index.php"><i class="fab fa-blogger-b fa-3x text-white"></i></a>
            
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                <!-- <ul class="navbar-nav ">
                <li class="nav-item active">
                    <a class="nav-link text-primary b7" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-primary b7" href="#">Link</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-primary b7" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Dropdown
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item text-primary b7" href="#">Action</a>
                    <a class="dropdown-item text-primary b7" href="#">Another action</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-primary b7" href="#">Something else here</a>
                    </div>
                </li>
                </ul> -->

                <input type="button" name="submitbtn" class="btn btn-light text-transparent shadow-lg  b7 mr-2" onclick="window.location.href='admin/dashboard.php'" value="Sign in">
                <input type="button" name="submitbtn" class="btn btn-outline-light b7 shadow-lg" onclick="window.location.href='admin/signup.php'" value="Sign up">

            </div>
        </nav>
    </div>