<html lang="en-US">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title>Our Blogs | Find Affordable Legal Help with us </title>

    <meta name="description" content="Hello bloggers">

    <?php include("head_libs.php"); ?>


</head>

<body class="fontb bg33">
    <?php //include "header.php";?>
    



    

    <?php //include("footer.php"); ?>




    <?php include("footer.php"); ?>


    <?php include("footer_libs.php"); ?>


</body>

</html>