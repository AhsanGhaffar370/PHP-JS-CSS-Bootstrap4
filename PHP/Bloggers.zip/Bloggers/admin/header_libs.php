<link rel="shortcut icon" type="image/x-icon" href="../favicon.png" />

<meta name="description" content="welcome to dashboard">


<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=yes">


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" >


<link  href="../style.css" type="text/css" rel="stylesheet" media="screen" />
<link  href="../style2.css" type="text/css" rel="stylesheet" media="screen" />
<link  href="sidebar_menu.css" type="text/css" rel="stylesheet" media="screen" />

<link href='https://fonts.googleapis.com/css?family=Open Sans&display=swap' rel='stylesheet' />


