<?php include 'session_db.php'; ?>

<html lang="en-US">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title>Our Blogs | Find Affordable Legal Help with us </title>

    <?php include "header_libs.php";?>
    <style>
    </style>

</head>


<body class="fontb bg33">

    <div class="wrapper d-flex align-items-stretch">

        <?php include "sidebar_menu.php";?>

        <!-- Page Content  -->
        <div class="content-sec">

            <?php include "header.php";?>

            <div id="content" class="p-4 p-md-5 pt-5">

                <!-- <div class="container-fluid sh_md p-0 rounded">

                </div> -->

            </div>
        </div>
    </div>

    <?php //include("../footer.php"); ?>

    <?php include("footer_libs.php"); ?>



</body>

</html>