<footer class="" >
    <div class="footer_black">
    <div class="container">
    <div class="row font-weight-light pt-4 pb-4">
        
        <div class="col-12 col-lg-6 col-md-12 col-sm-12 text-center text-lg-left d-lg-flex align-items-center">
            <p class="size14 text-white font-weight-light">
            © 2020 <a href="index.php" class="foot1 font-weight-normal text-white b6" >Bloggers</a>. All Rights Reserved.
             
            </p>
        </div>

        <div class="col-12 col-lg-6 col-md-12 col-sm-12 text-center text-lg-right mt-3 mt-lg-2">
            <a href="#" class="btn btn-lg p-1"><i class="fab fa-facebook fa-1x foot1"></i></a>
            <a href="#" class="btn btn-lg p-1"><i class="fab fa-twitter fa-1x foot1"></i></a>
            <a href="#" class="btn btn-lg p-1"><i class="fab fa-instagram fa-1x foot1"></i></a>
            <a href="#" class="btn btn-lg p-1"><i class="fab fa-youtube fa-1x foot1"></i></a>
        </div>
    </div>
    </div>
    </div>

</footer>